var searchData=
[
  ['insert',['insert',['../classFatTable.html#ae5bcce7262ced6cab5a164c40307c350',1,'FatTable::insert()'],['../classSector.html#a934dc752fbfb2b98075c500904b2ca6b',1,'Sector::insert()'],['../classCluster.html#a75218b99ef972794e1571f6937fc09e2',1,'Cluster::insert()'],['../classTrack.html#a9c119d10ee46f6e00fd37425b78d1a43',1,'Track::insert()'],['../classCylinder.html#a466d02af745ee3e548e4cba1ac752644',1,'Cylinder::insert()']]],
  ['insert_5ffile',['insert_file',['../classHardDrive.html#abe41cc759c1ef69c3588cac961a13bed',1,'HardDrive']]]
];
